/**
 * @file
 * @brief
 * @date 2024-06-30
 * @author user
 */

#ifndef V2X_SW_LTEV2X_HAL_DEFINES_H
#define V2X_SW_LTEV2X_HAL_DEFINES_H

#endif //V2X_SW_LTEV2X_HAL_DEFINES_H
